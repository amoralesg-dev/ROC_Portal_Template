import { inject } from '@angular/core';

import {
    CanActivateFn,
    Router
} from '@angular/router';

import { Auth } from '../services/auth';

export const authGuard: CanActivateFn = () => {

   

    const auth = inject(Auth);

    const router = inject(Router);

    console.log(
        'AUTHENTICATED:',
        auth.isAuthenticated()
    );

    if (auth.isAuthenticated()) {

        return true;

    }


    router.navigate([
        '/login'
    ]);

    return false;

};