import * as i0 from '@angular/core';
import { Input, Component, ViewChild, ContentChild, EventEmitter, Output, signal, Injectable, inject } from '@angular/core';
import * as i1 from '@angular/common';
import { CommonModule } from '@angular/common';
import * as i2 from 'primeng/table';
import { TableModule } from 'primeng/table';
import * as i4 from 'primeng/inputtext';
import { InputTextModule } from 'primeng/inputtext';
import * as i1$1 from 'primeng/api';
import * as i1$2 from 'primeng/dialog';
import { DialogModule } from 'primeng/dialog';
import * as i1$3 from 'primeng/toast';
import { ToastModule } from 'primeng/toast';
import * as i1$4 from 'primeng/confirmdialog';
import { ConfirmDialogModule } from 'primeng/confirmdialog';
import * as i1$5 from 'primeng/progressspinner';
import { ProgressSpinnerModule } from 'primeng/progressspinner';
import Aura from '@primeuix/themes/aura';
import { definePreset } from '@primeuix/themes';
import { providePrimeNG } from 'primeng/config';
import * as i1$6 from '@angular/router';
import { RouterModule } from '@angular/router';

class PageHeaderComponent {
    title = '';
    subtitle = '';
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.0.6", ngImport: i0, type: PageHeaderComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "21.0.6", type: PageHeaderComponent, isStandalone: true, selector: "app-page-header", inputs: { title: "title", subtitle: "subtitle" }, ngImport: i0, template: "<div class=\"page-header\">\r\n    <div>\r\n        <h1>{{ title }}</h1>\r\n\r\n        @if (subtitle) {\r\n            <span>{{ subtitle }}</span>\r\n        }\r\n    </div>\r\n</div>", styles: [".page-header{background:var(--surface-card);border-radius:12px;padding:1rem 1.5rem;margin-bottom:1.5rem;box-shadow:0 1px 4px #0000000d}.page-header h1{margin:0;font-size:1.8rem;font-weight:600}.page-header span{display:block;margin-top:.25rem;color:var(--text-color-secondary);font-size:.9rem}\n"] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.0.6", ngImport: i0, type: PageHeaderComponent, decorators: [{
            type: Component,
            args: [{ selector: 'app-page-header', standalone: true, template: "<div class=\"page-header\">\r\n    <div>\r\n        <h1>{{ title }}</h1>\r\n\r\n        @if (subtitle) {\r\n            <span>{{ subtitle }}</span>\r\n        }\r\n    </div>\r\n</div>", styles: [".page-header{background:var(--surface-card);border-radius:12px;padding:1rem 1.5rem;margin-bottom:1.5rem;box-shadow:0 1px 4px #0000000d}.page-header h1{margin:0;font-size:1.8rem;font-weight:600}.page-header span{display:block;margin-top:.25rem;color:var(--text-color-secondary);font-size:.9rem}\n"] }]
        }], propDecorators: { title: [{
                type: Input
            }], subtitle: [{
                type: Input
            }] } });

class PageToolbarComponent {
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.0.6", ngImport: i0, type: PageToolbarComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "21.0.6", type: PageToolbarComponent, isStandalone: true, selector: "app-page-toolbar", ngImport: i0, template: "<div class=\"page-toolbar\">\r\n    <ng-content>works</ng-content>\r\n</div>", styles: [".page-toolbar{display:flex;align-items:center;gap:1rem;margin-bottom:1.5rem}\n"] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.0.6", ngImport: i0, type: PageToolbarComponent, decorators: [{
            type: Component,
            args: [{ selector: 'app-page-toolbar', standalone: true, template: "<div class=\"page-toolbar\">\r\n    <ng-content>works</ng-content>\r\n</div>", styles: [".page-toolbar{display:flex;align-items:center;gap:1rem;margin-bottom:1.5rem}\n"] }]
        }] });

class PageContentComponent {
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.0.6", ngImport: i0, type: PageContentComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "21.0.6", type: PageContentComponent, isStandalone: true, selector: "app-page-content", ngImport: i0, template: "<div class=\"page-content\">\r\n    <ng-content></ng-content>\r\n</div>", styles: [".page-content{background:var(--surface-card);border-radius:12px;padding:1.5rem}\n"] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.0.6", ngImport: i0, type: PageContentComponent, decorators: [{
            type: Component,
            args: [{ selector: 'app-page-content', standalone: true, template: "<div class=\"page-content\">\r\n    <ng-content></ng-content>\r\n</div>", styles: [".page-content{background:var(--surface-card);border-radius:12px;padding:1.5rem}\n"] }]
        }] });

class DataTable {
    columns = [];
    data = [];
    paginator = true;
    rows = 10;
    rowsPerPageOptions = [5, 10, 20, 50];
    globalFilterFields = [];
    loading = false;
    actionsTemplate;
    table;
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.0.6", ngImport: i0, type: DataTable, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "21.0.6", type: DataTable, isStandalone: true, selector: "app-data-table", inputs: { columns: "columns", data: "data", paginator: "paginator", rows: "rows", rowsPerPageOptions: "rowsPerPageOptions", globalFilterFields: "globalFilterFields", loading: "loading" }, queries: [{ propertyName: "actionsTemplate", first: true, predicate: ["actions"], descendants: true }], viewQueries: [{ propertyName: "table", first: true, predicate: ["dt"], descendants: true }], ngImport: i0, template: "<div class=\"data-table-header\">\r\n\r\n    <input\r\n        pInputText\r\n        type=\"text\"\r\n        placeholder=\"Buscar...\"\r\n        (input)=\"table.filterGlobal($any($event.target).value, 'contains')\">\r\n\r\n</div>\r\n\r\n<p-table\r\n    #dt\r\n    [value]=\"data\"\r\n    [loading]=\"loading\"\r\n    [paginator]=\"paginator\"\r\n    [rows]=\"rows\"\r\n    [rowsPerPageOptions]=\"rowsPerPageOptions\"\r\n    [globalFilterFields]=\"globalFilterFields\"\r\n    [tableStyle]=\"{ 'min-width': '50rem' }\">\r\n\r\n    <ng-template pTemplate=\"header\">\r\n        <tr>\r\n\r\n            @for (column of columns; track column.field) {\r\n\r\n                @if (column.sortable) {\r\n\r\n                    <th [pSortableColumn]=\"column.field\">\r\n\r\n                        {{ column.header }}\r\n\r\n                        <p-sortIcon\r\n                            [field]=\"column.field\">\r\n                        </p-sortIcon>\r\n\r\n                    </th>\r\n\r\n                } @else {\r\n\r\n                    <th>\r\n                        {{ column.header }}\r\n                    </th>\r\n\r\n                }\r\n\r\n            }\r\n\r\n        </tr>\r\n    </ng-template>\r\n\r\n    <ng-template pTemplate=\"body\" let-row>\r\n        <tr>\r\n\r\n            @for (column of columns; track column.field) {\r\n\r\n                <td>\r\n\r\n                    @if (column.type === 'actions') {\r\n\r\n                        <ng-container\r\n                            *ngTemplateOutlet=\"\r\n                                actionsTemplate;\r\n                                context: { $implicit: row }\r\n                            \">\r\n                        </ng-container>\r\n\r\n                    } @else {\r\n\r\n                        {{ row[column.field] }}\r\n\r\n                    }\r\n\r\n                </td>\r\n\r\n            }\r\n\r\n        </tr>\r\n    </ng-template>\r\n\r\n    <ng-template pTemplate=\"emptymessage\">\r\n\r\n        <tr>\r\n\r\n            <td [attr.colspan]=\"columns.length\">\r\n\r\n                <div class=\"empty-state\">\r\n\r\n                    <i class=\"pi pi-inbox\"></i>\r\n\r\n                    <div class=\"empty-state-title\">\r\n                        No se encontraron registros\r\n                    </div>\r\n\r\n                    <div class=\"empty-state-subtitle\">\r\n                        Ajusta los filtros o intenta una nueva b\u00FAsqueda\r\n                    </div>\r\n\r\n                </div>\r\n\r\n            </td>\r\n\r\n        </tr>\r\n\r\n    </ng-template>\r\n\r\n</p-table>", styles: [":host{display:block}.data-table-header{display:flex;justify-content:flex-end;margin-bottom:1rem}.empty-state{display:flex;flex-direction:column;align-items:center;gap:.5rem;padding:2rem}.empty-state i{font-size:2rem}.empty-state-title{font-weight:600}.empty-state-subtitle{color:var(--text-color-secondary);font-size:.9rem}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }, { kind: "directive", type: i1.NgTemplateOutlet, selector: "[ngTemplateOutlet]", inputs: ["ngTemplateOutletContext", "ngTemplateOutlet", "ngTemplateOutletInjector"] }, { kind: "ngmodule", type: TableModule }, { kind: "component", type: i2.Table, selector: "p-table", inputs: ["frozenColumns", "frozenValue", "styleClass", "tableStyle", "tableStyleClass", "paginator", "pageLinks", "rowsPerPageOptions", "alwaysShowPaginator", "paginatorPosition", "paginatorStyleClass", "paginatorDropdownAppendTo", "paginatorDropdownScrollHeight", "currentPageReportTemplate", "showCurrentPageReport", "showJumpToPageDropdown", "showJumpToPageInput", "showFirstLastIcon", "showPageLinks", "defaultSortOrder", "sortMode", "resetPageOnSort", "selectionMode", "selectionPageOnly", "contextMenuSelection", "contextMenuSelectionMode", "dataKey", "metaKeySelection", "rowSelectable", "rowTrackBy", "lazy", "lazyLoadOnInit", "compareSelectionBy", "csvSeparator", "exportFilename", "filters", "globalFilterFields", "filterDelay", "filterLocale", "expandedRowKeys", "editingRowKeys", "rowExpandMode", "scrollable", "rowGroupMode", "scrollHeight", "virtualScroll", "virtualScrollItemSize", "virtualScrollOptions", "virtualScrollDelay", "frozenWidth", "contextMenu", "resizableColumns", "columnResizeMode", "reorderableColumns", "loading", "loadingIcon", "showLoader", "rowHover", "customSort", "showInitialSortBadge", "exportFunction", "exportHeader", "stateKey", "stateStorage", "editMode", "groupRowsBy", "size", "showGridlines", "stripedRows", "groupRowsByOrder", "responsiveLayout", "breakpoint", "paginatorLocale", "value", "columns", "first", "rows", "totalRecords", "sortField", "sortOrder", "multiSortMeta", "selection", "selectAll"], outputs: ["contextMenuSelectionChange", "selectAllChange", "selectionChange", "onRowSelect", "onRowUnselect", "onPage", "onSort", "onFilter", "onLazyLoad", "onRowExpand", "onRowCollapse", "onContextMenuSelect", "onColResize", "onColReorder", "onRowReorder", "onEditInit", "onEditComplete", "onEditCancel", "onHeaderCheckboxToggle", "sortFunction", "firstChange", "rowsChange", "onStateSave", "onStateRestore"] }, { kind: "directive", type: i1$1.PrimeTemplate, selector: "[pTemplate]", inputs: ["type", "pTemplate"] }, { kind: "directive", type: i2.SortableColumn, selector: "[pSortableColumn]", inputs: ["pSortableColumn", "pSortableColumnDisabled"] }, { kind: "component", type: i2.SortIcon, selector: "p-sortIcon", inputs: ["field"] }, { kind: "ngmodule", type: InputTextModule }, { kind: "directive", type: i4.InputText, selector: "[pInputText]", inputs: ["hostName", "ptInputText", "pInputTextPT", "pInputTextUnstyled", "pSize", "variant", "fluid", "invalid"] }] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.0.6", ngImport: i0, type: DataTable, decorators: [{
            type: Component,
            args: [{ selector: 'app-data-table', standalone: true, imports: [
                        CommonModule,
                        TableModule,
                        InputTextModule
                    ], template: "<div class=\"data-table-header\">\r\n\r\n    <input\r\n        pInputText\r\n        type=\"text\"\r\n        placeholder=\"Buscar...\"\r\n        (input)=\"table.filterGlobal($any($event.target).value, 'contains')\">\r\n\r\n</div>\r\n\r\n<p-table\r\n    #dt\r\n    [value]=\"data\"\r\n    [loading]=\"loading\"\r\n    [paginator]=\"paginator\"\r\n    [rows]=\"rows\"\r\n    [rowsPerPageOptions]=\"rowsPerPageOptions\"\r\n    [globalFilterFields]=\"globalFilterFields\"\r\n    [tableStyle]=\"{ 'min-width': '50rem' }\">\r\n\r\n    <ng-template pTemplate=\"header\">\r\n        <tr>\r\n\r\n            @for (column of columns; track column.field) {\r\n\r\n                @if (column.sortable) {\r\n\r\n                    <th [pSortableColumn]=\"column.field\">\r\n\r\n                        {{ column.header }}\r\n\r\n                        <p-sortIcon\r\n                            [field]=\"column.field\">\r\n                        </p-sortIcon>\r\n\r\n                    </th>\r\n\r\n                } @else {\r\n\r\n                    <th>\r\n                        {{ column.header }}\r\n                    </th>\r\n\r\n                }\r\n\r\n            }\r\n\r\n        </tr>\r\n    </ng-template>\r\n\r\n    <ng-template pTemplate=\"body\" let-row>\r\n        <tr>\r\n\r\n            @for (column of columns; track column.field) {\r\n\r\n                <td>\r\n\r\n                    @if (column.type === 'actions') {\r\n\r\n                        <ng-container\r\n                            *ngTemplateOutlet=\"\r\n                                actionsTemplate;\r\n                                context: { $implicit: row }\r\n                            \">\r\n                        </ng-container>\r\n\r\n                    } @else {\r\n\r\n                        {{ row[column.field] }}\r\n\r\n                    }\r\n\r\n                </td>\r\n\r\n            }\r\n\r\n        </tr>\r\n    </ng-template>\r\n\r\n    <ng-template pTemplate=\"emptymessage\">\r\n\r\n        <tr>\r\n\r\n            <td [attr.colspan]=\"columns.length\">\r\n\r\n                <div class=\"empty-state\">\r\n\r\n                    <i class=\"pi pi-inbox\"></i>\r\n\r\n                    <div class=\"empty-state-title\">\r\n                        No se encontraron registros\r\n                    </div>\r\n\r\n                    <div class=\"empty-state-subtitle\">\r\n                        Ajusta los filtros o intenta una nueva b\u00FAsqueda\r\n                    </div>\r\n\r\n                </div>\r\n\r\n            </td>\r\n\r\n        </tr>\r\n\r\n    </ng-template>\r\n\r\n</p-table>", styles: [":host{display:block}.data-table-header{display:flex;justify-content:flex-end;margin-bottom:1rem}.empty-state{display:flex;flex-direction:column;align-items:center;gap:.5rem;padding:2rem}.empty-state i{font-size:2rem}.empty-state-title{font-weight:600}.empty-state-subtitle{color:var(--text-color-secondary);font-size:.9rem}\n"] }]
        }], propDecorators: { columns: [{
                type: Input
            }], data: [{
                type: Input
            }], paginator: [{
                type: Input
            }], rows: [{
                type: Input
            }], rowsPerPageOptions: [{
                type: Input
            }], globalFilterFields: [{
                type: Input
            }], loading: [{
                type: Input
            }], actionsTemplate: [{
                type: ContentChild,
                args: ['actions']
            }], table: [{
                type: ViewChild,
                args: ['dt']
            }] } });

class AppDialog {
    visible = false;
    title = '';
    width = '50rem';
    visibleChange = new EventEmitter();
    footerTemplate;
    onHide() {
        this.visible = false;
        this.visibleChange.emit(false);
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.0.6", ngImport: i0, type: AppDialog, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "21.0.6", type: AppDialog, isStandalone: true, selector: "app-app-dialog", inputs: { visible: "visible", title: "title", width: "width" }, outputs: { visibleChange: "visibleChange" }, queries: [{ propertyName: "footerTemplate", first: true, predicate: ["footer"], descendants: true }], ngImport: i0, template: "<p-dialog\r\n    [header]=\"title\"\r\n    [(visible)]=\"visible\"\r\n    [modal]=\"true\"\r\n    [style]=\"{ width: width }\"\r\n    (onHide)=\"onHide()\">\r\n\r\n    <ng-content></ng-content>\r\n\r\n    <hr>\r\n\r\n\r\n\r\n</p-dialog>", styles: [":host{display:block}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }, { kind: "ngmodule", type: DialogModule }, { kind: "component", type: i1$2.Dialog, selector: "p-dialog", inputs: ["hostName", "header", "draggable", "resizable", "contentStyle", "contentStyleClass", "modal", "closeOnEscape", "dismissableMask", "rtl", "closable", "breakpoints", "styleClass", "maskStyleClass", "maskStyle", "showHeader", "blockScroll", "autoZIndex", "baseZIndex", "minX", "minY", "focusOnShow", "maximizable", "keepInViewport", "focusTrap", "transitionOptions", "maskMotionOptions", "motionOptions", "closeIcon", "closeAriaLabel", "closeTabindex", "minimizeIcon", "maximizeIcon", "closeButtonProps", "maximizeButtonProps", "visible", "style", "position", "role", "appendTo", "content", "contentTemplate", "footerTemplate", "closeIconTemplate", "maximizeIconTemplate", "minimizeIconTemplate", "headlessTemplate"], outputs: ["onShow", "onHide", "visibleChange", "onResizeInit", "onResizeEnd", "onDragEnd", "onMaximize"] }] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.0.6", ngImport: i0, type: AppDialog, decorators: [{
            type: Component,
            args: [{ selector: 'app-app-dialog', standalone: true, imports: [
                        CommonModule,
                        DialogModule
                    ], template: "<p-dialog\r\n    [header]=\"title\"\r\n    [(visible)]=\"visible\"\r\n    [modal]=\"true\"\r\n    [style]=\"{ width: width }\"\r\n    (onHide)=\"onHide()\">\r\n\r\n    <ng-content></ng-content>\r\n\r\n    <hr>\r\n\r\n\r\n\r\n</p-dialog>", styles: [":host{display:block}\n"] }]
        }], propDecorators: { visible: [{
                type: Input
            }], title: [{
                type: Input
            }], width: [{
                type: Input
            }], visibleChange: [{
                type: Output
            }], footerTemplate: [{
                type: ContentChild,
                args: ['footer']
            }] } });

class AppToast {
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.0.6", ngImport: i0, type: AppToast, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "21.0.6", type: AppToast, isStandalone: true, selector: "app-app-toast", ngImport: i0, template: "<p-toast></p-toast>", styles: [":host{display:block}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }, { kind: "ngmodule", type: ToastModule }, { kind: "component", type: i1$3.Toast, selector: "p-toast", inputs: ["key", "autoZIndex", "baseZIndex", "life", "styleClass", "position", "preventOpenDuplicates", "preventDuplicates", "showTransformOptions", "hideTransformOptions", "showTransitionOptions", "hideTransitionOptions", "motionOptions", "breakpoints"], outputs: ["onClose"] }] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.0.6", ngImport: i0, type: AppToast, decorators: [{
            type: Component,
            args: [{ selector: 'app-app-toast', standalone: true, imports: [
                        CommonModule,
                        ToastModule
                    ], template: "<p-toast></p-toast>", styles: [":host{display:block}\n"] }]
        }] });

class AppConfirmDialog {
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.0.6", ngImport: i0, type: AppConfirmDialog, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "21.0.6", type: AppConfirmDialog, isStandalone: true, selector: "app-app-confirm-dialog", ngImport: i0, template: "<p-confirmDialog></p-confirmDialog>", styles: [":host{display:block}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }, { kind: "ngmodule", type: ConfirmDialogModule }, { kind: "component", type: i1$4.ConfirmDialog, selector: "p-confirmDialog, p-confirmdialog, p-confirm-dialog", inputs: ["header", "icon", "message", "style", "styleClass", "maskStyleClass", "acceptIcon", "acceptLabel", "closeAriaLabel", "acceptAriaLabel", "acceptVisible", "rejectIcon", "rejectLabel", "rejectAriaLabel", "rejectVisible", "acceptButtonStyleClass", "rejectButtonStyleClass", "closeOnEscape", "dismissableMask", "blockScroll", "rtl", "closable", "appendTo", "key", "autoZIndex", "baseZIndex", "transitionOptions", "focusTrap", "defaultFocus", "breakpoints", "modal", "visible", "position", "draggable"], outputs: ["onHide"] }] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.0.6", ngImport: i0, type: AppConfirmDialog, decorators: [{
            type: Component,
            args: [{ selector: 'app-app-confirm-dialog', standalone: true, imports: [
                        CommonModule,
                        ConfirmDialogModule
                    ], template: "<p-confirmDialog></p-confirmDialog>", styles: [":host{display:block}\n"] }]
        }] });

class Loader {
    loading = signal(false, ...(ngDevMode ? [{ debugName: "loading" }] : []));
    show() {
        this.loading.set(true);
    }
    hide() {
        this.loading.set(false);
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.0.6", ngImport: i0, type: Loader, deps: [], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.0.6", ngImport: i0, type: Loader, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.0.6", ngImport: i0, type: Loader, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root'
                }]
        }] });

class AppLoader {
    loader = inject(Loader);
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.0.6", ngImport: i0, type: AppLoader, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "21.0.6", type: AppLoader, isStandalone: true, selector: "app-app-loader", ngImport: i0, template: "@if (loader.loading()) {\r\n\r\n    <div class=\"loader-overlay\">\r\n\r\n        <div class=\"loader-container\">\r\n\r\n            <p-progressSpinner />\r\n\r\n            <span>\r\n                Cargando...\r\n            </span>\r\n\r\n        </div>\r\n\r\n    </div>\r\n\r\n}", styles: [".loader-overlay{position:fixed;inset:0;z-index:9999;display:flex;align-items:center;justify-content:center;background:#00000059;-webkit-backdrop-filter:blur(2px);backdrop-filter:blur(2px)}.loader-container{display:flex;flex-direction:column;align-items:center;gap:1rem;padding:2rem;border-radius:12px;background:#fff}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }, { kind: "ngmodule", type: ProgressSpinnerModule }, { kind: "component", type: i1$5.ProgressSpinner, selector: "p-progressSpinner, p-progress-spinner, p-progressspinner", inputs: ["styleClass", "strokeWidth", "fill", "animationDuration", "ariaLabel"] }] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.0.6", ngImport: i0, type: AppLoader, decorators: [{
            type: Component,
            args: [{ selector: 'app-app-loader', standalone: true, imports: [
                        CommonModule,
                        ProgressSpinnerModule
                    ], template: "@if (loader.loading()) {\r\n\r\n    <div class=\"loader-overlay\">\r\n\r\n        <div class=\"loader-container\">\r\n\r\n            <p-progressSpinner />\r\n\r\n            <span>\r\n                Cargando...\r\n            </span>\r\n\r\n        </div>\r\n\r\n    </div>\r\n\r\n}", styles: [".loader-overlay{position:fixed;inset:0;z-index:9999;display:flex;align-items:center;justify-content:center;background:#00000059;-webkit-backdrop-filter:blur(2px);backdrop-filter:blur(2px)}.loader-container{display:flex;flex-direction:column;align-items:center;gap:1rem;padding:2rem;border-radius:12px;background:#fff}\n"] }]
        }] });

class Toast {
    messageService;
    constructor(messageService) {
        this.messageService = messageService;
    }
    success(detail, summary = 'Éxito') {
        this.messageService.add({
            severity: 'success',
            summary,
            detail
        });
    }
    error(detail, summary = 'Error') {
        this.messageService.add({
            severity: 'error',
            summary,
            detail
        });
    }
    warn(detail, summary = 'Advertencia') {
        this.messageService.add({
            severity: 'warn',
            summary,
            detail
        });
    }
    info(detail, summary = 'Información') {
        this.messageService.add({
            severity: 'info',
            summary,
            detail
        });
    }
    clear() {
        this.messageService.clear();
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.0.6", ngImport: i0, type: Toast, deps: [{ token: i1$1.MessageService }], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.0.6", ngImport: i0, type: Toast, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.0.6", ngImport: i0, type: Toast, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root'
                }]
        }], ctorParameters: () => [{ type: i1$1.MessageService }] });

class Dialog {
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.0.6", ngImport: i0, type: Dialog, deps: [], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.0.6", ngImport: i0, type: Dialog, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.0.6", ngImport: i0, type: Dialog, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root',
                }]
        }] });

const RassiniPreset = definePreset(Aura, {
    primitive: {
        gray: {
            50: '#F8F9FA',
            100: '#F1F3F5',
            200: '#E9ECEF',
            300: '#DEE2E6',
            400: '#CED4DA',
            500: '#ADB5BD',
            600: '#868E96',
            700: '#6C757D',
            800: '#565A5C',
            900: '#343A40',
            950: '#212529'
        },
        orange: {
            50: '#FFF7ED',
            100: '#FFEDD5',
            200: '#FED7AA',
            300: '#FDBA74',
            400: '#FB923C',
            // Colores corporativos Rassini
            500: '#F39C12',
            600: '#E98300',
            700: '#D2492A',
            800: '#B03A1E',
            900: '#7C2D12',
            950: '#431407'
        }
    },
    semantic: {
        primary: {
            50: '{orange.50}',
            100: '{orange.100}',
            200: '{orange.200}',
            300: '{orange.300}',
            400: '{orange.400}',
            500: '{orange.500}',
            600: '{orange.600}',
            700: '{orange.700}',
            800: '{orange.800}',
            900: '{orange.900}',
            950: '{orange.950}'
        },
        colorScheme: {
            light: {
                content: {
                    background: '{gray.50}'
                },
                surface: {
                    0: '#FFFFFF',
                    50: '{gray.50}',
                    100: '{gray.100}',
                    200: '{gray.200}',
                    300: '{gray.300}',
                    400: '{gray.400}',
                    500: '{gray.500}',
                    600: '{gray.600}',
                    700: '{gray.700}',
                    800: '{gray.800}',
                    900: '{gray.900}',
                    950: '{gray.950}'
                }
            }
        }
    }
});

function provideRassiniTheme() {
    return providePrimeNG({
        theme: {
            preset: RassiniPreset,
            options: {
                darkModeSelector: '.app-dark'
            }
        }
    });
}

class RassiniSidebar {
    menu = [];
    visible = true;
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.0.6", ngImport: i0, type: RassiniSidebar, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "21.0.6", type: RassiniSidebar, isStandalone: true, selector: "rui-sidebar", inputs: { menu: "menu", visible: "visible" }, ngImport: i0, template: `
        <aside class="rui-sidebar" [class.hidden]="!visible">

            <ul class="rui-menu">

                @for (group of menu; track group.label) {

                    <li class="rui-menu-group">

                        <div class="rui-menu-group-title">
                            {{ group.label }}
                        </div>

                        @if (group.items) {

                            <ul>

                                @for (item of group.items; track item.label) {

                                    <li>

                                        <a
                                            [routerLink]="item.routerLink"
                                            routerLinkActive="active">

                                            <i
                                                [class]="item.icon">
                                            </i>

                                            <span>
                                                {{ item.label }}
                                            </span>

                                        </a>

                                    </li>

                                }

                            </ul>

                        }

                    </li>

                }

            </ul>

        </aside>
    `, isInline: true, styles: [".rui-sidebar{position:fixed;top:5.5rem;left:1rem;width:18rem;height:calc(100vh - 7rem);overflow-y:auto;z-index:999;-webkit-user-select:none;user-select:none;padding:1.5rem 1rem;border-radius:1.25rem;background:#ffffffe0;-webkit-backdrop-filter:blur(18px);backdrop-filter:blur(18px);border:1px solid rgba(0,0,0,.04);box-shadow:0 4px 20px #0000000a;transition:transform .2s ease,left .2s ease}.rui-menu{margin:0;padding:0;list-style:none}.rui-menu-group{margin-bottom:2rem}.rui-menu-group-title{margin-bottom:1rem;padding-left:.5rem;font-size:.85rem;font-weight:600;text-transform:uppercase;letter-spacing:.03rem;color:#565a5c}.rui-menu-group ul{margin:0;padding:0;list-style:none}.rui-menu-group li{margin-bottom:.25rem}.rui-menu-group a{display:flex;align-items:center;gap:.75rem;padding:.85rem 1rem;border-radius:.75rem;text-decoration:none;color:var(--text-color);transition:background-color .2s,color .2s;cursor:pointer}.rui-menu-group a:hover{background:#f59a2a1a}.rui-menu-group a.active{color:var(--primary-color);font-weight:700}.rui-menu-group a.active i{color:var(--primary-color)}.rui-menu-group i{width:1rem;min-width:1rem;font-size:1rem;color:#6c757d}.rui-menu-group span{font-size:1rem}.rui-sidebar::-webkit-scrollbar{width:6px}.rui-sidebar::-webkit-scrollbar-track{background:transparent}.rui-sidebar::-webkit-scrollbar-thumb{background:#00000026;border-radius:10px}.rui-sidebar::-webkit-scrollbar-thumb:hover{background:#00000040}.rui-sidebar.hidden{transform:translate(-120%)}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }, { kind: "ngmodule", type: RouterModule }, { kind: "directive", type: i1$6.RouterLink, selector: "[routerLink]", inputs: ["target", "queryParams", "fragment", "queryParamsHandling", "state", "info", "relativeTo", "preserveFragment", "skipLocationChange", "replaceUrl", "routerLink"] }, { kind: "directive", type: i1$6.RouterLinkActive, selector: "[routerLinkActive]", inputs: ["routerLinkActiveOptions", "ariaCurrentWhenActive", "routerLinkActive"], outputs: ["isActiveChange"], exportAs: ["routerLinkActive"] }] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.0.6", ngImport: i0, type: RassiniSidebar, decorators: [{
            type: Component,
            args: [{ selector: 'rui-sidebar', standalone: true, imports: [
                        CommonModule,
                        RouterModule
                    ], template: `
        <aside class="rui-sidebar" [class.hidden]="!visible">

            <ul class="rui-menu">

                @for (group of menu; track group.label) {

                    <li class="rui-menu-group">

                        <div class="rui-menu-group-title">
                            {{ group.label }}
                        </div>

                        @if (group.items) {

                            <ul>

                                @for (item of group.items; track item.label) {

                                    <li>

                                        <a
                                            [routerLink]="item.routerLink"
                                            routerLinkActive="active">

                                            <i
                                                [class]="item.icon">
                                            </i>

                                            <span>
                                                {{ item.label }}
                                            </span>

                                        </a>

                                    </li>

                                }

                            </ul>

                        }

                    </li>

                }

            </ul>

        </aside>
    `, styles: [".rui-sidebar{position:fixed;top:5.5rem;left:1rem;width:18rem;height:calc(100vh - 7rem);overflow-y:auto;z-index:999;-webkit-user-select:none;user-select:none;padding:1.5rem 1rem;border-radius:1.25rem;background:#ffffffe0;-webkit-backdrop-filter:blur(18px);backdrop-filter:blur(18px);border:1px solid rgba(0,0,0,.04);box-shadow:0 4px 20px #0000000a;transition:transform .2s ease,left .2s ease}.rui-menu{margin:0;padding:0;list-style:none}.rui-menu-group{margin-bottom:2rem}.rui-menu-group-title{margin-bottom:1rem;padding-left:.5rem;font-size:.85rem;font-weight:600;text-transform:uppercase;letter-spacing:.03rem;color:#565a5c}.rui-menu-group ul{margin:0;padding:0;list-style:none}.rui-menu-group li{margin-bottom:.25rem}.rui-menu-group a{display:flex;align-items:center;gap:.75rem;padding:.85rem 1rem;border-radius:.75rem;text-decoration:none;color:var(--text-color);transition:background-color .2s,color .2s;cursor:pointer}.rui-menu-group a:hover{background:#f59a2a1a}.rui-menu-group a.active{color:var(--primary-color);font-weight:700}.rui-menu-group a.active i{color:var(--primary-color)}.rui-menu-group i{width:1rem;min-width:1rem;font-size:1rem;color:#6c757d}.rui-menu-group span{font-size:1rem}.rui-sidebar::-webkit-scrollbar{width:6px}.rui-sidebar::-webkit-scrollbar-track{background:transparent}.rui-sidebar::-webkit-scrollbar-thumb{background:#00000026;border-radius:10px}.rui-sidebar::-webkit-scrollbar-thumb:hover{background:#00000040}.rui-sidebar.hidden{transform:translate(-120%)}\n"] }]
        }], propDecorators: { menu: [{
                type: Input
            }], visible: [{
                type: Input
            }] } });

class RassiniTopbar {
    menuToggle = new EventEmitter();
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.0.6", ngImport: i0, type: RassiniTopbar, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "21.0.6", type: RassiniTopbar, isStandalone: true, selector: "rui-topbar", outputs: { menuToggle: "menuToggle" }, ngImport: i0, template: `
        <header class="rui-topbar">

            <div class="rui-topbar-left">

                <button
                    type="button"
                    class="rui-menu-button"
                    (click)="menuToggle.emit()">

                    <i class="pi pi-bars"></i>

                </button>

                <img
                    src="assets/images/rassini-logo.png"
                    alt="Rassini"
                    class="rui-logo">

            </div>

            <div class="rui-topbar-right">

                <i class="pi pi-calendar"></i>

                <i class="pi pi-inbox"></i>

                <i class="pi pi-user"></i>

            </div>

        </header>
    `, isInline: true, styles: [".rui-topbar{height:4rem;background:#ffffffe6;-webkit-backdrop-filter:blur(18px);backdrop-filter:blur(18px);display:flex;align-items:center;justify-content:space-between;padding:0 1.5rem;border-bottom:1px solid rgba(0,0,0,.04)}.rui-topbar-left{display:flex;align-items:center;gap:1rem}.rui-topbar-right{display:flex;align-items:center;gap:1.5rem;color:#6c757d;font-size:1.1rem}.rui-logo{height:42px;width:auto}.rui-menu-button{border:none;background:transparent;cursor:pointer;font-size:1.25rem;color:#6c757d}\n"] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.0.6", ngImport: i0, type: RassiniTopbar, decorators: [{
            type: Component,
            args: [{ selector: 'rui-topbar', standalone: true, template: `
        <header class="rui-topbar">

            <div class="rui-topbar-left">

                <button
                    type="button"
                    class="rui-menu-button"
                    (click)="menuToggle.emit()">

                    <i class="pi pi-bars"></i>

                </button>

                <img
                    src="assets/images/rassini-logo.png"
                    alt="Rassini"
                    class="rui-logo">

            </div>

            <div class="rui-topbar-right">

                <i class="pi pi-calendar"></i>

                <i class="pi pi-inbox"></i>

                <i class="pi pi-user"></i>

            </div>

        </header>
    `, styles: [".rui-topbar{height:4rem;background:#ffffffe6;-webkit-backdrop-filter:blur(18px);backdrop-filter:blur(18px);display:flex;align-items:center;justify-content:space-between;padding:0 1.5rem;border-bottom:1px solid rgba(0,0,0,.04)}.rui-topbar-left{display:flex;align-items:center;gap:1rem}.rui-topbar-right{display:flex;align-items:center;gap:1.5rem;color:#6c757d;font-size:1.1rem}.rui-logo{height:42px;width:auto}.rui-menu-button{border:none;background:transparent;cursor:pointer;font-size:1.25rem;color:#6c757d}\n"] }]
        }], propDecorators: { menuToggle: [{
                type: Output
            }] } });

class RassiniShell {
    menu = [];
    sidebarVisibleChange = new EventEmitter();
    sidebarVisible = true;
    get sidebarHidden() {
        return !this.sidebarVisible;
    }
    toggleSidebar() {
        this.sidebarVisible = !this.sidebarVisible;
        this.sidebarVisibleChange.emit(this.sidebarVisible);
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.0.6", ngImport: i0, type: RassiniShell, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "21.0.6", type: RassiniShell, isStandalone: true, selector: "rui-shell", inputs: { menu: "menu" }, outputs: { sidebarVisibleChange: "sidebarVisibleChange" }, ngImport: i0, template: `
        <rui-topbar
            (menuToggle)="toggleSidebar()">
        </rui-topbar>

        <rui-sidebar
            [visible]="sidebarVisible"
            [menu]="menu">
        </rui-sidebar>

        <ng-content></ng-content>
    `, isInline: true, styles: [":host{display:contents}:host(.rui-shell-sidebar-hidden)~.layout-main-container,.rui-shell-sidebar-hidden+.layout-main-container{margin-left:0!important}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }, { kind: "component", type: RassiniTopbar, selector: "rui-topbar", outputs: ["menuToggle"] }, { kind: "component", type: RassiniSidebar, selector: "rui-sidebar", inputs: ["menu", "visible"] }] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.0.6", ngImport: i0, type: RassiniShell, decorators: [{
            type: Component,
            args: [{ selector: 'rui-shell', standalone: true, imports: [
                        CommonModule,
                        RassiniTopbar,
                        RassiniSidebar,
                    ], template: `
        <rui-topbar
            (menuToggle)="toggleSidebar()">
        </rui-topbar>

        <rui-sidebar
            [visible]="sidebarVisible"
            [menu]="menu">
        </rui-sidebar>

        <ng-content></ng-content>
    `, styles: [":host{display:contents}:host(.rui-shell-sidebar-hidden)~.layout-main-container,.rui-shell-sidebar-hidden+.layout-main-container{margin-left:0!important}\n"] }]
        }], propDecorators: { menu: [{
                type: Input
            }], sidebarVisibleChange: [{
                type: Output
            }] } });

/*
 * Public API Surface of rassini-ui
 */

/**
 * Generated bundle index. Do not edit.
 */

export { AppConfirmDialog, AppDialog, AppLoader, AppToast, DataTable, Dialog, Loader, PageContentComponent, PageHeaderComponent, PageToolbarComponent, RassiniPreset, RassiniShell, RassiniSidebar, RassiniTopbar, Toast, provideRassiniTheme };
//# sourceMappingURL=rassini-ui.mjs.map
