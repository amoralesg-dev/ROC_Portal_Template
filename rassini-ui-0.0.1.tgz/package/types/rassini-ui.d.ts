import * as i0 from '@angular/core';
import { TemplateRef, EventEmitter, EnvironmentProviders } from '@angular/core';
import { Table } from 'primeng/table';
import { MessageService } from 'primeng/api';
import * as _primeuix_themes_types from '@primeuix/themes/types';
import { CanActivateFn } from '@angular/router';

declare class PageHeaderComponent {
    title: string;
    subtitle: string;
    static ɵfac: i0.ɵɵFactoryDeclaration<PageHeaderComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<PageHeaderComponent, "app-page-header", never, { "title": { "alias": "title"; "required": false; }; "subtitle": { "alias": "subtitle"; "required": false; }; }, {}, never, never, true, never>;
}

declare class PageToolbarComponent {
    static ɵfac: i0.ɵɵFactoryDeclaration<PageToolbarComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<PageToolbarComponent, "app-page-toolbar", never, {}, {}, never, ["*"], true, never>;
}

declare class PageContentComponent {
    static ɵfac: i0.ɵɵFactoryDeclaration<PageContentComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<PageContentComponent, "app-page-content", never, {}, {}, never, ["*"], true, never>;
}

interface DataTableColumn {
    field: string;
    header: string;
    type?: 'text' | 'actions';
    sortable?: boolean;
}
declare class DataTable {
    columns: DataTableColumn[];
    data: any[];
    paginator: boolean;
    rows: number;
    rowsPerPageOptions: number[];
    globalFilterFields: string[];
    loading: boolean;
    actionsTemplate?: TemplateRef<any>;
    table: Table;
    static ɵfac: i0.ɵɵFactoryDeclaration<DataTable, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DataTable, "app-data-table", never, { "columns": { "alias": "columns"; "required": false; }; "data": { "alias": "data"; "required": false; }; "paginator": { "alias": "paginator"; "required": false; }; "rows": { "alias": "rows"; "required": false; }; "rowsPerPageOptions": { "alias": "rowsPerPageOptions"; "required": false; }; "globalFilterFields": { "alias": "globalFilterFields"; "required": false; }; "loading": { "alias": "loading"; "required": false; }; }, {}, ["actionsTemplate"], never, true, never>;
}

declare class AppDialog {
    visible: boolean;
    title: string;
    width: string;
    visibleChange: EventEmitter<boolean>;
    footerTemplate?: TemplateRef<any>;
    onHide(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<AppDialog, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<AppDialog, "app-app-dialog", never, { "visible": { "alias": "visible"; "required": false; }; "title": { "alias": "title"; "required": false; }; "width": { "alias": "width"; "required": false; }; }, { "visibleChange": "visibleChange"; }, ["footerTemplate"], ["*"], true, never>;
}

declare class AppToast {
    static ɵfac: i0.ɵɵFactoryDeclaration<AppToast, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<AppToast, "app-app-toast", never, {}, {}, never, never, true, never>;
}

declare class AppConfirmDialog {
    static ɵfac: i0.ɵɵFactoryDeclaration<AppConfirmDialog, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<AppConfirmDialog, "app-app-confirm-dialog", never, {}, {}, never, never, true, never>;
}

declare class Loader {
    readonly loading: i0.WritableSignal<boolean>;
    show(): void;
    hide(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<Loader, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<Loader>;
}

declare class AppLoader {
    readonly loader: Loader;
    static ɵfac: i0.ɵɵFactoryDeclaration<AppLoader, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<AppLoader, "app-app-loader", never, {}, {}, never, never, true, never>;
}

interface PageRequest {
    page: number;
    size: number;
    sort?: string;
}

interface Page<T> {
    content: T[];
    totalElements: number;
    totalPages: number;
    pageNumber: number;
    pageSize: number;
}

interface Audit {
    createdBy?: string;
    createdDate?: Date;
    modifiedBy?: string;
    modifiedDate?: Date;
}

declare class Toast {
    private readonly messageService;
    constructor(messageService: MessageService);
    success(detail: string, summary?: string): void;
    error(detail: string, summary?: string): void;
    warn(detail: string, summary?: string): void;
    info(detail: string, summary?: string): void;
    clear(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<Toast, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<Toast>;
}

declare class Dialog {
    static ɵfac: i0.ɵɵFactoryDeclaration<Dialog, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<Dialog>;
}

declare const RassiniPreset: _primeuix_themes_types.Preset;

declare function provideRassiniTheme(): EnvironmentProviders;

interface RassiniMenuItem {
    label: string;
    icon?: string;
    routerLink?: string | string[];
    items?: RassiniMenuItem[];
    expanded?: boolean;
}

declare class RassiniSidebar {
    menu: RassiniMenuItem[];
    visible: boolean;
    itemClick: EventEmitter<void>;
    onItemClick(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<RassiniSidebar, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<RassiniSidebar, "rui-sidebar", never, { "menu": { "alias": "menu"; "required": false; }; "visible": { "alias": "visible"; "required": false; }; }, { "itemClick": "itemClick"; }, never, never, true, never>;
}

declare class RassiniTopbar {
    menuToggle: EventEmitter<void>;
    logout: EventEmitter<void>;
    testLogout(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<RassiniTopbar, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<RassiniTopbar, "rui-topbar", never, {}, { "menuToggle": "menuToggle"; "logout": "logout"; }, never, never, true, never>;
}

declare class RassiniShell {
    menu: RassiniMenuItem[];
    sidebarVisibleChange: EventEmitter<boolean>;
    logout: EventEmitter<void>;
    sidebarVisible: boolean;
    get sidebarHidden(): boolean;
    toggleSidebar(): void;
    closeSidebar(): void;
    closeSidebarMobile(): void;
    onLogout(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<RassiniShell, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<RassiniShell, "rui-shell", never, { "menu": { "alias": "menu"; "required": false; }; }, { "sidebarVisibleChange": "sidebarVisibleChange"; "logout": "logout"; }, never, ["*"], true, never>;
}

declare class RassiniLogin {
    username: string;
    password: string;
    errorMessage: string;
    loading: boolean;
    loginEvent: EventEmitter<{
        username: string;
        password: string;
    }>;
    onLogin(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<RassiniLogin, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<RassiniLogin, "rui-login", never, { "errorMessage": { "alias": "errorMessage"; "required": false; }; "loading": { "alias": "loading"; "required": false; }; }, { "loginEvent": "loginEvent"; }, never, never, true, never>;
}

declare class Auth {
    private readonly STORAGE_KEY;
    login(username: string, password: string): boolean;
    logout(): void;
    isAuthenticated(): boolean;
    getSession(): any;
    static ɵfac: i0.ɵɵFactoryDeclaration<Auth, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<Auth>;
}

declare const authGuard: CanActivateFn;

export { AppConfirmDialog, AppDialog, AppLoader, AppToast, Auth, DataTable, Dialog, Loader, PageContentComponent, PageHeaderComponent, PageToolbarComponent, RassiniLogin, RassiniPreset, RassiniShell, RassiniSidebar, RassiniTopbar, Toast, authGuard, provideRassiniTheme };
export type { Audit, DataTableColumn, Page, PageRequest, RassiniMenuItem };
