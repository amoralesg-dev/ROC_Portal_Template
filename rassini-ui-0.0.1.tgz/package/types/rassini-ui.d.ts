import * as i0 from '@angular/core';
import { TemplateRef, EventEmitter } from '@angular/core';
import { Table } from 'primeng/table';
import { MessageService } from 'primeng/api';

declare class PageHeaderComponent {
    title: string;
    subtitle: string;
    static ɵfac: i0.ɵɵFactoryDeclaration<PageHeaderComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<PageHeaderComponent, "app-page-header", never, { "title": { "alias": "title"; "required": false; }; "subtitle": { "alias": "subtitle"; "required": false; }; }, {}, never, never, true, never>;
}

declare class PageToolbarComponent {
    static ɵfac: i0.ɵɵFactoryDeclaration<PageToolbarComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<PageToolbarComponent, "app-page-toolbar", never, {}, {}, never, ["*"], true, never>;
}

declare class PageContentComponent {
    static ɵfac: i0.ɵɵFactoryDeclaration<PageContentComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<PageContentComponent, "app-page-content", never, {}, {}, never, ["*"], true, never>;
}

interface DataTableColumn {
    field: string;
    header: string;
    type?: 'text' | 'actions';
    sortable?: boolean;
}
declare class DataTable {
    columns: DataTableColumn[];
    data: any[];
    paginator: boolean;
    rows: number;
    rowsPerPageOptions: number[];
    globalFilterFields: string[];
    loading: boolean;
    actionsTemplate?: TemplateRef<any>;
    table: Table;
    static ɵfac: i0.ɵɵFactoryDeclaration<DataTable, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DataTable, "app-data-table", never, { "columns": { "alias": "columns"; "required": false; }; "data": { "alias": "data"; "required": false; }; "paginator": { "alias": "paginator"; "required": false; }; "rows": { "alias": "rows"; "required": false; }; "rowsPerPageOptions": { "alias": "rowsPerPageOptions"; "required": false; }; "globalFilterFields": { "alias": "globalFilterFields"; "required": false; }; "loading": { "alias": "loading"; "required": false; }; }, {}, ["actionsTemplate"], never, true, never>;
}

declare class AppDialog {
    visible: boolean;
    title: string;
    width: string;
    visibleChange: EventEmitter<boolean>;
    footerTemplate?: TemplateRef<any>;
    onHide(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<AppDialog, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<AppDialog, "app-app-dialog", never, { "visible": { "alias": "visible"; "required": false; }; "title": { "alias": "title"; "required": false; }; "width": { "alias": "width"; "required": false; }; }, { "visibleChange": "visibleChange"; }, ["footerTemplate"], ["*"], true, never>;
}

declare class AppToast {
    static ɵfac: i0.ɵɵFactoryDeclaration<AppToast, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<AppToast, "app-app-toast", never, {}, {}, never, never, true, never>;
}

declare class AppConfirmDialog {
    static ɵfac: i0.ɵɵFactoryDeclaration<AppConfirmDialog, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<AppConfirmDialog, "app-app-confirm-dialog", never, {}, {}, never, never, true, never>;
}

declare class Loader {
    readonly loading: i0.WritableSignal<boolean>;
    show(): void;
    hide(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<Loader, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<Loader>;
}

declare class AppLoader {
    readonly loader: Loader;
    static ɵfac: i0.ɵɵFactoryDeclaration<AppLoader, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<AppLoader, "app-app-loader", never, {}, {}, never, never, true, never>;
}

interface PageRequest {
    page: number;
    size: number;
    sort?: string;
}

interface Page<T> {
    content: T[];
    totalElements: number;
    totalPages: number;
    pageNumber: number;
    pageSize: number;
}

interface Audit {
    createdBy?: string;
    createdDate?: Date;
    modifiedBy?: string;
    modifiedDate?: Date;
}

declare class Toast {
    private readonly messageService;
    constructor(messageService: MessageService);
    success(detail: string, summary?: string): void;
    error(detail: string, summary?: string): void;
    warn(detail: string, summary?: string): void;
    info(detail: string, summary?: string): void;
    clear(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<Toast, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<Toast>;
}

declare class Dialog {
    static ɵfac: i0.ɵɵFactoryDeclaration<Dialog, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<Dialog>;
}

export { AppConfirmDialog, AppDialog, AppLoader, AppToast, DataTable, Dialog, Loader, PageContentComponent, PageHeaderComponent, PageToolbarComponent, Toast };
export type { Audit, DataTableColumn, Page, PageRequest };
