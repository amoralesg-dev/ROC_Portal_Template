export * from './app.config';

